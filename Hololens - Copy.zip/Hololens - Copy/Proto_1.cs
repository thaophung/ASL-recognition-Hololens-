﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public class Proto_1 : MonoBehaviour
{
    // Variables and Objects
    char[] oldDisplayBar;
    char[] newDisplayBar;
    GameObject[] slotArray;
    float timeCounter;
    string Alphabet = "_ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    char currentChar;
    GameObject Slot1;
    GameObject Slot2;
    GameObject Slot3;
    GameObject Slot4;
    GameObject Slot5;
    GameObject Slot6;
    GameObject Slot7;
    GameObject Slot8;
    GameObject Slot9;
    GameObject Slot10;
    GameObject Slot11;
    GameObject Slot12;
    GameObject Slot13;
    GameObject Slot14;
    GameObject Slot15;
    GameObject Slot16;
    GameObject Slot17;
    GameObject Slot18;
    GameObject Slot19;
    GameObject Slot20;

    Texture LetterA;
    Texture LetterB;
    Texture LetterC;
    Texture LetterD;
    Texture LetterE;
    Texture LetterF;
    Texture LetterG;
    Texture LetterH;
    Texture LetterI;
    Texture LetterJ;
    Texture LetterK;
    Texture LetterL;
    Texture LetterM;
    Texture LetterN;
    Texture LetterO;
    Texture LetterP;
    Texture LetterQ;
    Texture LetterR;
    Texture LetterS;
    Texture LetterT;
    Texture LetterU;
    Texture LetterV;
    Texture LetterW;
    Texture LetterX;
    Texture LetterY;
    Texture LetterZ;


    // Use this for initialization
    void Start ()
    {
        print("Starting.");

        // Assign Slots
        GameObject Slot1 = GameObject.Find("Slot 1");
        GameObject Slot2 = GameObject.Find("Slot 2");
        GameObject Slot3 = GameObject.Find("Slot 3");
        GameObject Slot4 = GameObject.Find("Slot 4");
        GameObject Slot5 = GameObject.Find("Slot 5");
        GameObject Slot6 = GameObject.Find("Slot 6");
        GameObject Slot7 = GameObject.Find("Slot 7");
        GameObject Slot8 = GameObject.Find("Slot 8");
        GameObject Slot9 = GameObject.Find("Slot 9");
        GameObject Slot10 = GameObject.Find("Slot 10");
        GameObject Slot11 = GameObject.Find("Slot 11");
        GameObject Slot12 = GameObject.Find("Slot 12");
        GameObject Slot13 = GameObject.Find("Slot 13");
        GameObject Slot14 = GameObject.Find("Slot 14");
        GameObject Slot15 = GameObject.Find("Slot 15");
        GameObject Slot16 = GameObject.Find("Slot 16");
        GameObject Slot17 = GameObject.Find("Slot 17");
        GameObject Slot18 = GameObject.Find("Slot 18");
        GameObject Slot19 = GameObject.Find("Slot 19");
        GameObject Slot20 = GameObject.Find("Slot 20");

        // Assign Letter Textures
        LetterA = Resources.Load("Alphabet/A") as Texture;
        LetterB = Resources.Load("Alphabet/B") as Texture;
        LetterC = Resources.Load("Alphabet/C") as Texture;
        LetterD = Resources.Load("Alphabet/D") as Texture;
        LetterE = Resources.Load("Alphabet/E") as Texture;
        LetterF = Resources.Load("Alphabet/F") as Texture;
        LetterG = Resources.Load("Alphabet/G") as Texture;
        LetterH = Resources.Load("Alphabet/H") as Texture;
        LetterI = Resources.Load("Alphabet/I") as Texture;
        LetterJ = Resources.Load("Alphabet/J") as Texture;
        LetterK = Resources.Load("Alphabet/K") as Texture;
        LetterL = Resources.Load("Alphabet/L") as Texture;
        LetterM = Resources.Load("Alphabet/M") as Texture;
        LetterN = Resources.Load("Alphabet/N") as Texture;
        LetterO = Resources.Load("Alphabet/O") as Texture;
        LetterP = Resources.Load("Alphabet/P") as Texture;
        LetterQ = Resources.Load("Alphabet/Q") as Texture;
        LetterR = Resources.Load("Alphabet/R") as Texture;
        LetterS = Resources.Load("Alphabet/S") as Texture;
        LetterT = Resources.Load("Alphabet/T") as Texture;
        LetterU = Resources.Load("Alphabet/U") as Texture;
        LetterV = Resources.Load("Alphabet/V") as Texture;
        LetterW = Resources.Load("Alphabet/W") as Texture;
        LetterX = Resources.Load("Alphabet/X") as Texture;
        LetterY = Resources.Load("Alphabet/Y") as Texture;
        LetterZ = Resources.Load("Alphabet/Z") as Texture;

        // Array for Display Bar 20 char spaces.
        oldDisplayBar = new char[] { '_', '_', '_', '_', '_', '_', '_', '_', '_', '_',
                                        '_', '_', '_', '_', '_', '_', '1', '_', '_', '_' };
        newDisplayBar = new char[] { '_', '_', '_', '_', '_', '_', '_', '_', '_', '_',
                                        '_', '_', '_', '_', '_', '_', '_', '_', '_', '_' };
        // Array for slot objects
        slotArray = new GameObject[] { Slot1, Slot2, Slot3, Slot4, Slot5,
                                        Slot6, Slot7, Slot8, Slot9, Slot10,
                                        Slot11, Slot12, Slot13, Slot14, Slot15,
                                        Slot16, Slot17, Slot18, Slot19, Slot20 };

        timeCounter = 0;
	}
	
	// Update is called once per frame
	void Update ()
    {
        timeCounter += Time.deltaTime;

        
        if (timeCounter >= .5)
        {
            // Generate a random letter
            currentChar = Alphabet[UnityEngine.Random.Range(0, Alphabet.Length)];

            // Copy old bar to a new one with all spaces shifted left by 1
            Array.Copy(oldDisplayBar, 1, newDisplayBar, 0, oldDisplayBar.Length - 1);

            // Place new letter into end of displaybar
            newDisplayBar[newDisplayBar.Length - 1] = currentChar;

            // Make the display bar into a printable string
            string printDBar = new string(newDisplayBar);

            // print the bar
            print("Display Bar: " + printDBar);

            // Update Slot Textures
            UpdateSlotTextures();

            // reset timer
            timeCounter = 0;
        }

        // Set current displaybar as old displaybar
        oldDisplayBar = newDisplayBar;
	}

    void UpdateSlotTextures()
    {
        for (int i = 0; i < newDisplayBar.Length; i++)
        {
            char c = newDisplayBar[i];
            switch(c)
            {
                case '_':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = Resources.Load("unity_builtin_extra/Default-Material") as Texture;
                        break;
                    }
                case 'A':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterA;
                        break;
                    }
                case 'B':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterB;
                        break;
                    }
                case 'C':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterC;
                        break;
                    }
                case 'D':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterD;
                        break;
                    }
                case 'E':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterE;
                        break;
                    }
                case 'F':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterF;
                        break;
                    }
                case 'G':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterG;
                        break;
                    }
                case 'H':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterH;
                        break;
                    }
                case 'I':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterI;
                        break;
                    }
                case 'J':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterJ;
                        break;
                    }
                case 'K':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterK;
                        break;
                    }
                case 'L':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterL;
                        break;
                    }
                case 'M':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterM;
                        break;
                    }
                case 'N':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterN;
                        break;
                    }
                case 'O':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterO;
                        break;
                    }
                case 'P':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterP;
                        break;
                    }
                case 'Q':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterQ;
                        break;
                    }
                case 'R':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterR;
                        break;
                    }
                case 'S':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterS;
                        break;
                    }
                case 'T':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterT;
                        break;
                    }
                case 'U':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterU;
                        break;
                    }
                case 'V':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterV;
                        break;
                    }
                case 'W':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterW;
                        break;
                    }
                case 'X':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterX;
                        break;
                    }
                case 'Y':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterY;
                        break;
                    }
                case 'Z':
                    {
                        slotArray[i].GetComponent<Renderer>().material.mainTexture = LetterZ;
                        break;
                    }
            }
            
        }
        
    }
}
